package com.bbb.codm

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF080809)
private val Panel = Color(0xFF171216)
private val Red = Color(0xFFE3263A)
private val Muted = Color(0xFFB9A8AC)
private val White = Color(0xFFF7F1F2)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Red, secondary = Color(0xFFFF596A),
                background = Bg, surface = Panel,
                onPrimary = White, onBackground = White, onSurface = White
            )) {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    BBBApp()
                }
            }
        }
    }
}

@Composable
private fun BBBApp() {
    val prefs = androidx.compose.ui.platform.LocalContext.current
        .getSharedPreferences("bbb_settings", 0)
    var page by remember { mutableStateOf("الرئيسية") }
    var fps by remember { mutableStateOf(prefs.getString("fps", "أعلى معدل متاح") ?: "أعلى معدل متاح") }
    var graphics by remember { mutableStateOf(prefs.getString("graphics", "متوسطة") ?: "متوسطة") }
    var fov by remember { mutableFloatStateOf(prefs.getFloat("fov", 90f)) }
    var shape by remember { mutableStateOf(prefs.getString("shape", "كلاسيكي") ?: "كلاسيكي") }
    var size by remember { mutableFloatStateOf(prefs.getFloat("size", 34f)) }
    var thickness by remember { mutableFloatStateOf(prefs.getFloat("thickness", 3f)) }
    var gap by remember { mutableFloatStateOf(prefs.getFloat("gap", 9f)) }
    var crossColor by remember { mutableStateOf(prefs.getString("crossColor", "أحمر") ?: "أحمر") }
    var dot by remember { mutableStateOf(prefs.getBoolean("dot", true)) }
    var saved by remember { mutableStateOf("") }

    val pages = listOf("الرئيسية", "الأداء", "التصويب", "Crosshair", "الحماية", "حول")
    Surface(Modifier.fillMaxSize(), color = Bg) {
        Row(Modifier.fillMaxSize().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Column(
                Modifier.width(190.dp).fillMaxHeight()
                    .background(Panel, RoundedCornerShape(22.dp)).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("BBB", color = Red, fontSize = 32.sp, fontWeight = FontWeight.Black)
                Text("CODM EDITION", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
                HorizontalDivider(color = Red.copy(alpha = .4f))
                pages.forEach { name ->
                    Button(
                        onClick = { page = name; saved = "" },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (page == name) Red else Color(0xFF292126)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 12.dp)
                    ) { Text(name, fontWeight = FontWeight.SemiBold) }
                }
                Spacer(Modifier.weight(1f))
                Text("الإصدار 1.1.0", color = Muted, fontSize = 11.sp)
                Text("وضع إعدادات مستقل", color = Color(0xFF69D39A), fontSize = 11.sp)
            }

            Column(Modifier.weight(1f).fillMaxHeight()) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("مركز التحكم BBB", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                        Text("مخصص لجهاز Xiaomi Pad 8 Pro · شاشة أفقية", color = Muted, fontSize = 12.sp)
                    }
                    Surface(color = Color(0xFF173426), shape = RoundedCornerShape(50)) {
                        Text("● جاهز", color = Color(0xFF75E0A6), modifier = Modifier.padding(horizontal = 14.dp, vertical = 7.dp))
                    }
                }
                Spacer(Modifier.height(12.dp))
                LazyColumn(
                    Modifier.fillMaxSize().background(Panel, RoundedCornerShape(22.dp)).padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    item {
                        when (page) {
                            "الرئيسية" -> {
                                Text("أهلاً بك في BBB", color = Red, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                                Text("تطبيق مستقل لحفظ وتنظيم إعدادات Call of Duty: Mobile.", color = White)
                                Text("الأقسام المتاحة: الأداء، التصويب، محرر Crosshair، وحماية الحساب.", color = Muted)
                                Text("ملاحظة: التطبيق لا يحقن ملفات اللعبة ولا يتصل بها ولا يغيّر إعداداتها تلقائياً.", color = Muted)
                            }
                            "الأداء" -> {
                                Text("إعدادات الأداء", color = Red, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                Text("معدل الإطارات المفضل")
                                ChoiceRow(listOf("60 FPS", "90 FPS", "120 FPS", "أعلى معدل متاح"), fps) { fps = it }
                                Text("جودة الرسومات")
                                ChoiceRow(listOf("منخفضة", "متوسطة", "عالية"), graphics) { graphics = it }
                                Text("مجال الرؤية FOV: ${fov.toInt()}°")
                                Slider(value = fov, onValueChange = { fov = it }, valueRange = 60f..120f)
                                Text("اختر فقط الخيارات التي تظهر داخل اللعبة؛ التوفر يختلف حسب إصدار اللعبة والنمط.", color = Muted, fontSize = 12.sp)
                            }
                            "التصويب" -> {
                                Text("إعدادات التصويب", color = Red, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                Text("استخدم خيارات Aim Assist والحساسية والجيروسكوب الرسمية داخل اللعبة.")
                                Text("يمكنك تدوين إعداداتك وحفظها هنا؛ لا يغيّر التطبيق ملفات CODM.", color = Muted)
                            }
                            "Crosshair" -> {
                                Text("محرر Crosshair", color = Red, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                Text("اختر شكلاً وعدّل الحجم والسماكة والمسافة واللون. المعاينة داخل التطبيق فقط.")
                                CrosshairPreview(shape, size, thickness, gap, crossColor, dot)
                                Text("الأشكال")
                                ChoiceRow(
                                    listOf("كلاسيكي", "نقطة", "＋", "×", "دائرة", "مربع", "T", "نجمة"),
                                    shape
                                ) { shape = it }
                                Text("الحجم: ${size.toInt()}")
                                Slider(value = size, onValueChange = { size = it }, valueRange = 12f..80f)
                                Text("السماكة: ${thickness.toInt()}")
                                Slider(value = thickness, onValueChange = { thickness = it }, valueRange = 1f..10f)
                                Text("المسافة بين الأذرع: ${gap.toInt()}")
                                Slider(value = gap, onValueChange = { gap = it }, valueRange = 0f..28f)
                                Text("اللون")
                                ChoiceRow(listOf("أحمر", "أخضر", "أبيض", "سماوي", "أصفر"), crossColor) { crossColor = it }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("إظهار النقطة الوسطى", modifier = Modifier.weight(1f))
                                    Switch(checked = dot, onCheckedChange = { dot = it })
                                }
                                Text("هذه معاينة تصميمية داخل التطبيق فقط، وليست طبقة فوق CODM أو أداة تصويب أثناء اللعب.", color = Muted, fontSize = 12.sp)
                            }
                            "الحماية" -> {
                                Text("حماية الحساب", color = Red, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                listOf("تجنب ملفات APK المعدلة للعبة", "لا تشارك بيانات تسجيل الدخول", "نزّل اللعبة من متجر رسمي", "تجنب أدوات الحقن والتلاعب").forEach {
                                    Text("• $it", color = White)
                                }
                            }
                            else -> {
                                Text("حول BBB", color = Red, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                Text("BBB – CODM Edition · الإصدار 1.1.0")
                                Text("تطبيق إعدادات مستقل باللغة العربية، بواجهة أفقية سوداء وحمراء.")
                            }
                        }
                    }
                    item {
                        Spacer(Modifier.height(4.dp))
                        Button(
                            onClick = {
                                prefs.edit().putString("fps", fps).putString("graphics", graphics)
                                    .putFloat("fov", fov).putString("shape", shape)
                                    .putFloat("size", size).putFloat("thickness", thickness)
                                    .putFloat("gap", gap).putString("crossColor", crossColor)
                                    .putBoolean("dot", dot).apply()
                                saved = "تم حفظ الإعدادات على الجهاز"
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Red),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp)
                        ) { Text("حفظ الإعدادات") }
                        if (saved.isNotBlank()) Text(saved, color = Color(0xFF75E0A6))
                    }
                }
            }
        }
    }
}

@Composable
private fun ChoiceRow(options: List<String>, selected: String, onSelect: (String) -> Unit) {
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
        options.forEach { option ->
            FilterChip(
                selected = selected == option,
                onClick = { onSelect(option) },
                label = { Text(option, fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = Red,
                    selectedLabelColor = White
                )
            )
        }
    }
}

private fun crosshairColor(name: String): Color = when (name) {
    "أخضر" -> Color(0xFF35E879)
    "أبيض" -> Color.White
    "سماوي" -> Color(0xFF37D9F5)
    "أصفر" -> Color(0xFFFFE44D)
    else -> Color(0xFFFF3045)
}

@Composable
private fun CrosshairPreview(shape: String, size: Float, thickness: Float, gap: Float, colorName: String, dot: Boolean) {
    val color = crosshairColor(colorName)
    Box(
        Modifier.fillMaxWidth().height(190.dp)
            .background(Color(0xFF090B10), RoundedCornerShape(16.dp))
            .border(1.dp, Red.copy(alpha = .5f), RoundedCornerShape(16.dp)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(180.dp)) {
            val c = center
            val unit = size.dp.toPx()
            val g = gap.dp.toPx()
            val sw = thickness.dp.toPx()
            val half = unit / 2f
            val cap = StrokeCap.Round
            when (shape) {
                "نقطة" -> drawCircle(color, radius = (thickness * 2.2f).dp.toPx(), center = c)
                "دائرة" -> drawCircle(color, radius = half, center = c, style = Stroke(sw))
                "مربع" -> drawRect(color, topLeft = Offset(c.x-half, c.y-half), size = androidx.compose.ui.geometry.Size(unit, unit), style = Stroke(sw))
                "×" -> {
                    drawLine(color, Offset(c.x-half,c.y-half), Offset(c.x+half,c.y+half), sw, cap)
                    drawLine(color, Offset(c.x-half,c.y+half), Offset(c.x+half,c.y-half), sw, cap)
                }
                "T" -> {
                    drawLine(color, Offset(c.x-half,c.y-half), Offset(c.x+half,c.y-half), sw, cap)
                    drawLine(color, Offset(c.x,c.y-half), Offset(c.x,c.y+half), sw, cap)
                }
                "نجمة" -> {
                    drawLine(color, Offset(c.x-half,c.y), Offset(c.x+half,c.y), sw, cap)
                    drawLine(color, Offset(c.x,c.y-half), Offset(c.x,c.y+half), sw, cap)
                    drawLine(color, Offset(c.x-half*.7f,c.y-half*.7f), Offset(c.x+half*.7f,c.y+half*.7f), sw, cap)
                    drawLine(color, Offset(c.x-half*.7f,c.y+half*.7f), Offset(c.x+half*.7f,c.y-half*.7f), sw, cap)
                }
                else -> {
                    drawLine(color, Offset(c.x-half,c.y), Offset(c.x-g,c.y), sw, cap)
                    drawLine(color, Offset(c.x+g,c.y), Offset(c.x+half,c.y), sw, cap)
                    drawLine(color, Offset(c.x,c.y-half), Offset(c.x,c.y-g), sw, cap)
                    drawLine(color, Offset(c.x,c.y+g), Offset(c.x,c.y+half), sw, cap)
                }
            }
            if (dot && shape != "نقطة") drawCircle(color, radius = (thickness * 1.15f).dp.toPx(), center = c)
        }
    }
}
