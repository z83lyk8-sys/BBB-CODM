# BBB – CODM Edition

مشروع Android أصلي باستخدام Kotlin وJetpack Compose، بواجهة عربية أفقية مناسبة للأجهزة اللوحية.

## المزايا
- لوحة إعدادات CODM مستقلة.
- تدوين خيارات FPS والرسومات وFOV.
- محرر Crosshair داخل التطبيق مع أشكال متعددة.
- التحكم بالحجم والسماكة والمسافة واللون والنقطة الوسطى.
- حفظ الاختيارات محلياً باستخدام SharedPreferences.
- واجهة سوداء وحمراء واتجاه أفقي إجباري.

## حدود الاستخدام
التطبيق لا يحقن كوداً في Call of Duty: Mobile، ولا يقرأ ذاكرة اللعبة، ولا يعرض Crosshair فوق اللعبة، ولا يتجاوز Anti-Cheat. معاينة Crosshair تظهر داخل التطبيق فقط. الإعدادات تُطبّق يدوياً من داخل اللعبة، والخيارات المتاحة تعتمد على إصدار CODM.

## البناء
1. افتح Android Studio (إصدار يدعم Android Gradle Plugin 8.7.3).
2. اختر **Open** وحدد مجلد المشروع `BBB_CODM_EDITION`.
3. انتظر Gradle Sync.
4. من القائمة اختر **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. ستجد APK عادةً في `app/build/outputs/apk/debug/app-debug.apk`.

المتطلبات: JDK 17 وAndroid SDK Platform 35.
