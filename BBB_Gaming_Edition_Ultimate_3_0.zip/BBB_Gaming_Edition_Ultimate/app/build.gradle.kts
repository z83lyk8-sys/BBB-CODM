plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.bbb.gaming"
    compileSdk = 35
    defaultConfig { applicationId = "com.bbb.gaming"; minSdk = 23; targetSdk = 35; versionCode = 3; versionName = "3.0 Ultimate" }
}
